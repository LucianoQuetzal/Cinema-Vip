// Package valid contains definitions of valid yaml configuration after its
// been parsed and validated.
package valid

const DefaultAutoPlanEnabled = true
