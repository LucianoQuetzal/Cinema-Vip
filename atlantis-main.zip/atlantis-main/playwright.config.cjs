module.exports = {
  testDir: './runatlantis.io/e2e'
};
