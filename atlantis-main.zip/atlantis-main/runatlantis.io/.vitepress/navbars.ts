const en = [
  { text: "Home", link: "/" },
  { text: "Guide", link: "/guide" },
  { text: "Docs", link: "/docs" },
  { text: "Contributing", link: "/contributing" },
  { text: "Blog", link: "/blog" },
];

export { en };
