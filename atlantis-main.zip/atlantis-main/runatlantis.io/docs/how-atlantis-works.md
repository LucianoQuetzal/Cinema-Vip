# How Atlantis Works

This section of docs talks about how Atlantis at deeper level.

* [Locking](locking.md)
* [Autoplanning](autoplanning.md)
* [Automerging](automerging.md)
* [Security](security.md)
