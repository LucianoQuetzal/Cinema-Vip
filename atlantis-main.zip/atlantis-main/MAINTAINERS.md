The current Maintainers Group for the [Atlantis] Project consists of:

| Name          | GitHub ID                                   | Employer          | Responsibilities |
| ------------- | ------------------------------------------- | ----------------- | ---------------- |
| Dylan Page    | [GenPage](https://github.com/GenPage)       | Lambda            | Maintainer       |
| PePe Amengual | [jamengual](https://github.com/jamengual)   | Slalom            | Maintainer       |
| Rui Chen      | [chenrui333](https://github.com/chenrui333) | Meetup            | Maintainer       |
| Ronak         | [nitrocode](https://github.com/nitrocode)   | RB Consulting LLC | Core Contributor |
